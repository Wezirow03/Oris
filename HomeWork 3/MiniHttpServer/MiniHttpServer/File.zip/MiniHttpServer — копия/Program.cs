﻿using MiniHttpServer.Settings;
using System.Text.Json;


namespace MiniHttpServer
{
    class Program
    {

        public static async Task Main()
        {

            var settings = Singleton.GetInstance();
            var server = new HttpServer(settings);
            server.Start();

            while (true)
            {
                string cmd = Console.ReadLine();
                if (cmd == "/stop")
                {
                    server.Stop();
                    break;
                }


                if (settings == null)
            {
                Console.WriteLine("Ошибка: Не удалось загрузить настройки.");
                return;
            }



            if (!System.IO.File.Exists("Public\\Gpt/gpt.html"))
            {
                Console.WriteLine("Ошибка: index.html не найден. Сервер не запущен.");
                return;
            }

            }
        }
    }
}